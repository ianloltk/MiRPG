///this code allows you to see which server u bot was added/removed///

///You need bot.onGuildJoin() and bot.onGuildLeave()///

module.exports = [{

    channel: "$randomChannelID",

    type: "guildJoin",

    code: `$title[1;I joined a New server!]

    $addField[1;Guild Name:;$guild;yes]

    $addField[1;Member Count:;$memberscount;yes]

    $addField[1;Guild ID:;$guildID;yes]

    $addField[1;Guild Owner:;$userTag[$ownerID];yes]

    $addField[1;Boosts:;$serverBoostCount;yes]

    $addField[1;Server Invite;$createServerInvite;yes]

    $color[1;GREEN]

    $thumbnail[1;$servericon]

    $dm[$botOwnerID]

    $wait[1ms]`

    },{

    channel: "$randomChannelID",

    type: "guildLeave",

    code: `

    $title[1;I was Removed from server]

    $addField[1;Guild Name:;$guild;yes]

    $addField[1;Member Count:;$memberscount;yes]

    $addField[1;Guild ID:;$guildID;yes]

    $addField[1;Guild Owner:;$userTag[$ownerID];yes]

    $addField[1;Boosts:;$serverBoostCount;yes]

    $color[1;RED]

    $thumbnail[1;$servericon]

    $dm[$botOwnerID]`

    }]

