module.exports = ({

 name: 'howgay',

   
    
 description: 'See how gay you are (100% real)',

 usage: 'howgay <@user>',

 aliases: ['gayrate','hg'],

 code: ` $title[gay r8 machine]

$description[<@$mentioned[1;yes]> is $random[1;100]% gay :gay_pride_flag:]

$color[RANDOM]`

})