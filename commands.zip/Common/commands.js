module.exports = {
name: "commands",
aliases: ["help", "cmds"],
code: `
$title[1;Commands]
$color[1;$getGlobalUserVar[EmbedColor]]
$description[1;
**Economy Commands**:
\`daily, fight, farm, forage, slots, dungeon, mine,
give, sellall, pethunt, hunt, blackjack, gamble\`

**Social Commands**:
\`hug, kill, slap, wave, laugh, marry, marriage,
divorce\`

**Fun Commands**:
\`repeat, 8ball, coinflip, neko, meme, afk, howgay\`

**Misc Commands**:
\`settings, ping, info,
 userinfo, avatar, banner, bot\`

**Stat Commands:**
\`inventory, achievements\`

**Shop Commands**:
\`shop, petshop, buypet, abandon, petinfo, heal, upgrade,
itemlist, sellall, sell<item>\`
 

$footer[1;Command Count: $commandsCount]
$suppressErrors
$globalCooldown[10s;Please wait before running this command again. This helps us enforce ratelimits. %time%]
`
}