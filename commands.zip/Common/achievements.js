module.exports = {
name: "achievements",
aliases: ['ac'],
$if: "v4",
code: `$onlyIf[$isBot[$findUser[$message;yes]]!=true;you cannot check a bot's achievements.]
$onlyIf[$getGlobalUserVar[UserInt;$findUser[$message;no]]!=False;This user has interaction commands disabled from their settings.]
$title[1;$username[$findUser[$message;yes]]'s achievements]
$description[1;**__On Another Level__**[$getGlobalUserVar[ATKAchievement;$findUser[$message;yes]]]\nUpgrade to 2ATK.\nReward:  +🪙150\n\n**__Your first time__** [$getGlobalUserVar[DailyAchievement;$findUser[$message;yes]]]\nCollect your daily reward for the first time.\nReward: +🪙100\n\n**__The family farm__**[$getGlobalUserVar[FarmAchievement;$findUser[$message;yes]]]\nGo farming at least once.\nReward: +🪙50\n\n**__Slots Addict__**[$getGlobalUserVar[slotAchievement;$findUser[$message;yes]]]\nSpent a total of $getVar[Coin]1000 on \`$getServerVar[Prefix;$guildID]slots\` (Current: $getVar[Coi]$getGlobalUserVar[slotAmount;$findUser[$message;yes]])\nReward: +🪙100\n\n]
$color[1;$getGlobalUserVar[EmbedColor;$authorID]]
$thumbnail[1;$userAvatar[$findUser[$message;yes]]]
$globalCooldown[5s;Please wait before running this command again. This helps us enforce ratelimits. %time%]

$onlyIf[$isBot[$authorID]!=true;]
`
}
