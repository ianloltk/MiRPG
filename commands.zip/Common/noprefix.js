module.exports = {
name: "<@996239241472389230>",
nonPrefixed: "true",
code: `Hello! my prefix for this server is: \`$getServerVar[Prefix;$guildID]\`
You can also ping me instead of using a prefix.
$globalCooldown[10s;]
`
}