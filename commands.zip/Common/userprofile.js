module.exports = {
name : "p",
aliases : ["profile", "user", "stats", "bal","balance"],
code: `
$onlyIf[$isBot[$findUser[$message;yes]]!=true;You cannot check a bot's profile.]
$onlyIf[$getGlobalUserVar[UserInt;$findUser[$message;no]]!=False;This user has interaction commands disabled from their settings.]
$title[1;$username[$findUser[$message;yes]]'s profile]
$description[1;
$getVar[Coi]**$getGlobalUserVar[Coins;$findUser[$message;yes]]** \`Coins\`
$getVar[Heart]**$getGlobalUserVar[HP;$findUser[$message;yes]]** \`HP\`
$getVar[Sord]**$getGlobalUserVar[ATK;$findUser[$message;yes]]** \`ATK\`
]
$thumbnail[1;$userAvatar[$findUser[$message;yes]]]
$color[1;$getGlobalUserVar[EmbedColor]]
$globalCooldown[5s;Please wait before running this command again. This helps us enforce ratelimits. %time%]
$onlyIf[$isBot[$authorID]!=true;]
`
}