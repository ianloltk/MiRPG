module.exports = [{
name : "hp",
aliases: "health",
code: `
$onlyIf[$getGlobalUserVar[HP]!=$getGlobalUserVar[MaxHP];You are at max hp :)]
$getVar[Heart]\`$getGlobalUserVar[HP]/$getGlobalUserVar[MaxHP]\`  | $getVar[Coi]\`$getGlobalUserVar[Coins;$authorID]\`\nHealing will cost you $getVar[Coi]**$multi[$sub[$getGlobalUserVar[MaxHP];$getGlobalUserVar[HP]];2]**.\nTo heal, run $getServerVar[Prefix;$guildID]heal
$suppressErrors
$onlyIf[$isBot[$authorID]!=true;]
`
},

{
name : "heal",
code : `
$setGlobalUserVar[HP;$getGlobalUserVar[MaxHP];$authorID]
$setGlobalUserVar[Coins;$sub[$getGlobalUserVar[Coins];$multi[$sub[$getGlobalUserVar[MaxHP];$getGlobalUserVar[HP]];2]]]
$wait[1s]
$onlyIf[$getGlobalUserVar[Coins]>=$multi[$sub[$getGlobalUserVar[MaxHP];$getGlobalUserVar[HP]];2];You do not have enough coins to heal.]
$onlyIf[$getGlobalUserVar[HP]!=$getGlobalUserVar[MaxHP];You are already at max hp :)]
$botTyping
$username[$authorID], You healed $getVar[Heart]**$sub[$getGlobalUserVar[MaxHP];$getGlobalUserVar[HP]]** for $getVar[Heart]**$multi[$sub[$getGlobalUserVar[MaxHP];$getGlobalUserVar[HP]];2]**.
$suppressErrors
$onlyIf[$isBot[$authorID]!=true;]
`
}]
