module.exports = {
name: "buyhp",
aliases: "buy hp",
code: `
You bought a hp drop for $getVar[Coi]**750**.
$setGlobalUserVar[MaxHP;$sum[$getGlobalUserVar[MaxHP];100];$authorID]
$setGlobalUserVar[Coins;$sub[$getGlobalUserVar[Coins];750]]
$onlyIf[$getGlobalUserVar[Coins;$authorID]>749;You do not have enough $getVar[Coi] to buy a **hpDrop**. You need at least $getVar[Coi]**750**.]
$onlyIf[$getGlobalUserVar[MaxHP;$authorID]<999;You have the maximum amount of hp.]
$suppressErrors
$onlyIf[$isBot[$authorID]!=true;]
`
}