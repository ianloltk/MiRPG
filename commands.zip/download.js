bot.functionManager.createCustomFunction({

  name: "download",

  type: "djs",

  code: async (d) => {

    const data = d.util.aoiFunc(d)

    const [url, filename] = data.inside.splits;

    if(!url || !url?.startsWith('https://')) return d.aoiError.fnError(d, 'custom', {inside: data.inside}, 'You need to provide the url and url must be start with "https"');

    if(!filename) return d.aoiError.fnError(d, 'custom', {}, 'You need to give the file name');

    const https = require('https')

    const { createWriteStream } = require('fs')

    const file = createWriteStream()

    https.get(url, (res) => {file.pipe(res)})

    return {

      code: d.util.setCode(data)  

    }

  }

}) 

