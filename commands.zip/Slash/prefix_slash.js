module.exports = {
name: "prefix",
prototype: "slash",
type: "interaction",
code:`
$interactionReply[Hello! my prefix for this server is: \`$getServerVar[Prefix;$guildID]\`
You can also ping me instead of using a prefix.
Note that slash commands are in beta, more coming soon.]
`
}