module.exports = {
name: "beg",
code: `
You earned $getVar[Heart]$random[15;20] from begging. You also lost $random[1;5].
$setGlobalUserVar[Coins;$sum[$getGlobalUserVar[Coins];$random[15;20]];$authorID]
$setGlobalUserVar[HP;$sub[$getGlobalUserHP];$random[1;5]];$authorID]
$globalCooldown[20s;No one wants to give you money. %time%]

$onlyIf[$random[1;2]==1;No one gave you anything.]
$onlyIf[$isBot[$authorID]!=true;]
`
}
