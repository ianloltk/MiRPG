module.exports = {

name: "daily",

$if: "v4",

code: `

$if[$getGlobalUserVar[FirstDaily;$authorID]==False]

$getVar[Unlocked] You collected your daily reward of $getVar[Coi]100.

$setGlobalUserVar[Coins;$sum[$getGlobalUserVar[Coins];100]]

$setGlobalUserVar[FirstDaily;False]

$else

$getVar[Unlocked] You collected your daily reward of $getVar[Coi]100.

**Congratulations!** You unlocked an achievement: "Your first time"\n+$getVar[Coi]**100**.

$setGlobalUserVar[DailyAchievement;$getVar[Unlocked]]

$setGlobalUserVar[Coins;$sum[$getGlobalUserVar[Coins];200]]

$setGlobalUserVar[FirstDaily;False]

$endif

$globalCooldown[24h;You have already collected your daily reward today. Please come back in **%time%**.]

$suppressErrors

$onlyIf[$isBot[$authorID]!=true;]`

}

