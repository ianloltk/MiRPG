module.exports = {
name: "upgrade",
$if: "v4",
aliases: ["prestige", "rankup"],
code: `
$if[$getGlobalUserVar[ATK;$authorID]==1]
You upgraded to 2ATK for $getVar[Coi]**500**.
**Congratulations!** You unlocked an achievement: "On Another Level"\n+$getVar[Coi]**150**.
$setGlobalUserVar[Coins;$sub[$getGlobalUserVar[Coins];500];$authorID]
$setGlobalUserVar[Coins;$sum[$getGlobalUserVar[Coins];150];$authorID]
$setGlobalUserVar[ATK;2;$authorID]
$setGlobalUserVar[ATKAchievement;$getVar[Unlocked]]
$onlyIf[$getGlobalUserVar[Coins;$authorID]>499;You do not have enough $getVar[Coi] to upgrade. You need at least $getVar[Coi]**500**.]
$else

$if[$getGlobalUserVar[ATK;$authorID]==2]
You upgraded to 3ATK for $getVar[Coi]**1000**.
$setGlobalUserVar[Coins;$sub[$getGlobalUserVar[Coins];1000];$authorID]
$setGlobalUserVar[ATK;3;$authorID]
$onlyIf[$getGlobalUserVar[Coins;$authorID]>999;You do not have enough $getVar[Coi] to upgrade. You need at least $getVar[Coi]**1000**.]
$setGlobalUserVar[ATKAchievement;$getVar[Unlocked]]

$else
$if[$getGlobalUserVar[ATK;$authorID]==3]
You upgraded to 4ATK for $getVar[Coi]**1500**.
$setGlobalUserVar[Coins;$sub[$getGlobalUserVar[Coins];1500];$authorID]
$setGlobalUserVar[ATK;4;$authorID]
$onlyIf[$getGlobalUserVar[Coins;$authorID]>1499;You do not have enough $getVar[Coi] to upgrade. You need at least $getVar[Coi]**1500**.]
$setGlobalUserVar[ATKAchievement;$getVar[Unlocked]]

$else
$if[$getGlobalUserVar[ATK;$authorID]==4]
You upgraded to 5ATK for $getVar[Coi]**2000**.
$setGlobalUserVar[Coins;$sub[$getGlobalUserVar[Coins];2000];$authorID]
$setGlobalUserVar[ATK;5;$authorID]
$onlyIf[$getGlobalUserVar[Coins;$authorID]>1999;You do not have enough $getVar[Coi] to upgrade. You need at least $getVar[Coi]**2000**.]
$setGlobalUserVar[ATKAchievement;$getVar[Unlocked]]

$else
$if[$getGlobalUserVar[ATK;$authorID]==5]
You have the max ATK. Congrats!
$setGlobalUserVar[ATKAchievement;$getVar[Unlocked]]

$endif
$endif
$endif
$endif
$endif
$suppressErrors
	`
}
